import java.util.ArrayList;
import java.util.List;

public class Board {

    private int[][] blocks;

    private Integer hammingDist = null;

    private Integer manhattanDist = null;

    public Board(int[][] blocks) {
        this.blocks = blocks;
    }

    public int dimension() {
        return blocks.length;
    }

    public int hamming() {
        if (hammingDist == null) {
            int n = dimension();
            int dist = 0;
            for (int i = 0; i < n * n - 1; i++) {
                int row = i / n;
                int col = i % n;
                if (blocks[row][col] != i + 1)
                    dist += 1;
            }
            hammingDist = dist;
        }
        return hammingDist;
    }

    public int manhattan() {
        if (manhattanDist == null) {
            int n = dimension();
            int dist = 0;
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    int val = blocks[i][j];
                    if (val == 0) continue;
                    int row = (val - 1) / n;
                    int col = (val - 1) % n;
                    dist += Math.abs(i - row) + Math.abs(j - col);
                }
            }
            manhattanDist = dist;
        }
        return manhattanDist;
    }

    public boolean isGoal() {
        int n = dimension();
        for (int i = 0; i < n * n - 1; i++) {
            int row = i / n;
            int col = i % n;
            int val = blocks[row][col];
            if (val != i + 1)
                return false;
        }
        return blocks[n - 1][n - 1] == 0;
    }

    public Board twin() {
        int n = dimension();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n - 1; j++) {
                if (blocks[i][j] != 0 && blocks[i][j + 1] != 0) {
                    return new Board(exchange(i, j, i, j + 1));
                }
            }
        }
        return new Board(copy());
    }

    public Iterable<Board> neighbors() {
        List<Board> neighbors = new ArrayList<Board>();
        int row = -1, col = -1, n = dimension();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (blocks[i][j] == 0) {
                    row = i;
                    col = j;
                    break;
                }
            }
        }
        if (row > 0) {
            neighbors.add(new Board(exchange(row, col, row - 1, col)));
        }
        if (col > 0) {
            neighbors.add(new Board(exchange(row, col, row, col - 1)));
        }
        if (row < n - 1) {
            neighbors.add(new Board(exchange(row, col, row + 1, col)));
        }
        if (col < n - 1) {
            neighbors.add(new Board(exchange(row, col, row, col + 1)));
        }
        return neighbors;
    }

    private int[][] exchange(int row_i, int col_i, int row_j, int col_j) {
        int[][] clones = copy();
        int temp = clones[row_i][col_i];
        clones[row_i][col_i] = clones[row_j][col_j];
        clones[row_j][col_j] = temp;
        return clones;
    }

    private int[][] copy() {
        int n = dimension();
        int[][] clone = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                clone[i][j] = blocks[i][j];
            }
        }
        return clone;
    }

    public boolean equals(Object y) {
        if (!(y instanceof Board))
            return false;
        Board yCast = (Board) y;
        if (yCast.dimension() != dimension())
            return false;
        int n = dimension();
        for (int i = 0; i < n * n; i++) {
            int row = i / n;
            int col = i % n;
            if (blocks[row][col] != yCast.blocks[row][col])
                return false;
        }
        return true;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        int n = dimension();
        sb.append(dimension()).append("\n");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                sb.append("\t").append(blocks[i][j]);
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        int[][] blocks1 = new int[][]{{1,2,3},{4,5,6},{7,8,0}};
        int[][] blocks2 = new int[][]{{1,2,3},{4,5,6},{7,8,0}};
        int[][] blocks3 = new int[][]{{8,1,3},{4,0,2},{7,6,5}};
        Board board1 = new Board(blocks1);
        Board board2 = new Board(blocks2);
        Board board3 = new Board(blocks3);
        System.out.println(board3.hamming());
        System.out.println(board3.manhattan());
        System.out.println(board1);
        for (Board board: board1.neighbors())
            System.out.println(board);
    }


}
